/** 
 * @author Anthony Wittemann
 * Chapter 3 Program 1 Employee Class
 * Chapter 6 Program 6 Employee Class modifications
 * HW Due 2/11/14 && Due 3/11/14
 */
public class AWEmployee {
	private String name;
	private int idNumber;
	private String department;
	private String position;
	
	public AWEmployee(){
		name = "";
		idNumber = 0;
		department = "";
		position = "";
	}
	
	public AWEmployee(String n, int idn, String d, String p){
		name = n;
		idNumber = idn;
		department = d;
		position = p;
	}
	
	public AWEmployee(String n, int idn){
		name = n;
		idNumber = idn;
		department = "";
		position = "";
	}
	
	/**
	 * 
	 * @param newName  - changes the name of the Employee
	 */
	public void setName(String newName){
		name = newName;
	}
	
	/**
	 * 
	 * @param newIDN  - changes the ID number of the Employee
	 */
	public void setIDNumber(int newIDN){
		idNumber = newIDN;
	}
	
	/**
	 * 
	 * @param newDept - changes the department of the Employee
	 */
	public void setDepartment(String newDept){
		department = newDept;
	}
	
	/**
	 * 
	 * @param newPos  - changes the position of the Employee
	 */
	public void setPosition(String newPos){
		position = newPos;
	}
	
	
	/**
	 * 
	 * @return returns the name of the Employee
	 */
	public String getName(){
		return name;
	}
	
	/**
	 * 
	 * @return returns the ID number of the Employee
	 */
	public int getIDNumber(){
		return idNumber;
	}

	/**
	 * 
	 * @return returns the department of the Employee
	 */
	public String getDepartment(){
		return department;
	}
	
	/**
	 * 
	 * @return returns the position of the Employee
	 */
	public String getPosition(){
		return position;
	}
	
	public String toString(){
		return "\nName: " + name + "\nID Number: " + idNumber + "\nDeparment: " + department + "\nPosition: " + position;
	}
	
	
}
