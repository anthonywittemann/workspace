import java.io.File;

/** 
 * @author Anthony Wittemann
 * Chapter 7 Program 11 - Number Analysis
 * HW Due 4/3/14
 */
public class AWCh7Pr11Driver {

	public static void main(String[] args) {
		//I couldn't find how to search for a file name and then return it's path
		// so I just entered in the path manually
		AWNumberAnalysis numAnal = new AWNumberAnalysis(new File("/Users/anthonywittemann/Documents/workspace/CSC142Albright/src/Numbers.txt"));

	}

}
