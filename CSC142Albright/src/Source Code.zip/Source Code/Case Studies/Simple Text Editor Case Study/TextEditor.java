/**
 * This program creates an instance of the TextEditorWindow
 * class, which displays a simple text editor window.
 */

public class TextEditor
{
    public static void main(String[] args)
    {
       TextEditorWindow te = new TextEditorWindow();
    }
}