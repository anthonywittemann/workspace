public class SuperClass1
{
   // Constructor   
   public SuperClass1()
   {
      System.out.println("This is the superclass " +
                         "constructor.");
   }
}
