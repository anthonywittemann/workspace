public class ClassA
{
     public void showMe()
     {
          System.out.println("me");
     }
}
