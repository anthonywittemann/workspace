/**
 * This program creates an instance of the SingleIntervalSelection
 * class which causes it to display its window.
 */

public class SingleIntervalSelectionDemo
{
     public static void main(String[] args)
     {
          SingleIntervalSelection sis = new SingleIntervalSelection();
     }
}

