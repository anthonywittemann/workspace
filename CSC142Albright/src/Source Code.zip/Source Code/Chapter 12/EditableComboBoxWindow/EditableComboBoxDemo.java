/**
 * This program creates an instance of the EditableComboBoxWindow
 * class, which causes it to display its window.
 */

public class EditableComboBoxDemo
{
     public static void main(String[] args)
     {
          EditableComboBoxWindow cbw = new EditableComboBoxWindow();
     }
}

