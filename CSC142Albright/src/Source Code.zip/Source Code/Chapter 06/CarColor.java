/**
 * CarColor enumerated data type 
 */

enum CarColor { RED, BLACK, BLUE, SILVER }