/* 
   PROGRAM: Comment2.java
   Written by Herbert Dorfmann
   This program calculates company payroll
   Last modification: 8/30/2005
*/

public class Comment2
{
   public static void main(String[] args)       
   {
      double payRate;      // Holds the hourly pay rate
      double hours;        // Holds the hours worked
      int employeeNumber;  // Holds the employee number
      
      // The Remainder of This Program is Omitted.
   }
}

