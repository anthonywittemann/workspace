// A well adjusted printing program

public class Adjusted
{
   public static void main(String[] args)
   {
      System.out.print("These are our top sellers:\n");
      System.out.print("Computer games\nCoffee\n");
      System.out.println("Aspirin");
   }
}
