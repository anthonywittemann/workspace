/**
 * This program creates an instance of the EventObjectWindow
 * class, which causes it to display its window.
 */

public class EventObjectDemo2
{
   public static void main(String[] args)
   {
      EventObjectWindow2 eow = new EventObjectWindow2();
   }
}