/**
 *  This program creates an instance of the
 *  SimpleWindow2 class. 
 */

public class SimpleWindow2Demo
{
   public static void main(String[] args)
   {
      SimpleWindow2 myWindow = new SimpleWindow2();
   }
}
