/**
 *  This program creates an instance of the
 *  KiloConverterWindow class, which displays
 *  a window on the screen.
 */

public class KilometerConverter
{
   public static void main(String[] args)
   {
      KiloConverterWindow kc = new KiloConverterWindow();
   }
}
