/** 
 * @author anthonywittemann
 * Call-back Interface
 * HW Due 4/22/14
 */
public interface AWCallback {
	void callback(int i);

}
