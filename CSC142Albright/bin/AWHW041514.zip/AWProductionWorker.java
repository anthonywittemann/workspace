/** 
 * @author Anthony Wittemann
 * Chapter 9 Program 1 - Employee and Production Worker Classes
 * In class 4/10/14
 */
public class AWProductionWorker extends AWEmployee{
	private int shift; //1 for day, 2 for night
	private double hrlyPayRate;
	
	public AWProductionWorker(){
		super();
		shift = 0;
		hrlyPayRate = 0;
	}
	
	public AWProductionWorker(String n, int hd, String en, int s, double hpr){
		super(n, hd, en);
		shift = s;
		hrlyPayRate = hpr;
	}
	
	public AWProductionWorker(String n, int hd, String en){
		super(n, hd, en);
		shift = 0;
		hrlyPayRate = 0;
	}
	
	
	public int getShift(){
		return shift;
	}
	
	public double getHrlyPayRate(){
		return hrlyPayRate;
	}
	
	public void setShift(int nS){
		shift = nS;
	}
	
	public void setHrlyPayRate(double nHPR){
		hrlyPayRate = nHPR;
	}
	
	public String toString(){
		String s;
		if(shift == 1){
			s = "day";
		}
		else if(shift == 2){
			s = "night";
		}
		else{
			s = "none";
		}
		return "Shift: " + s + "\nHourly Pay Rate: $" + hrlyPayRate;
	}
	
}
