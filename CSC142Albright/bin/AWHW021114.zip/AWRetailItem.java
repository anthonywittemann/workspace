/** 
 * @author Anthony Wittemann
 * Chapter 3 Program 4 Retail Items
 * HW Due 2/11/14
 */
public class AWRetailItem {
	private String description;
	private double price;
	private int unitsOnHand;
	
	public AWRetailItem(String descr, double pri, int UOH){
		description = descr;
		price = pri;
		unitsOnHand = UOH;
	}
	
	public void setDescription(String nDes){
		description = nDes;
	}
	
	public void setPrice(double nPri){
		price = nPri;
	}
	
	public void setUnitsOnHand(int nUOH){
		unitsOnHand = nUOH;
	}
	
	public String getDescription(){
		return description;
	}
	
	public double getPrice(){
		return price;
	}
	
	public int getUnitsOnHand(){
		return unitsOnHand;
	}

	
}
