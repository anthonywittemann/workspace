/** 
 * @author Anthony Wittemann
 * Chapter 3 Program 4 AWRetail Items
 * HW Due 2/11/14
 */
public class AWRetailProgram {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		AWRetailItem item1 = new AWRetailItem("Jacket", 59.95, 12);
		AWRetailItem item2 = new AWRetailItem("Designer Jeans", 34.95, 40);
		AWRetailItem item3 = new AWRetailItem("Shirt", 24.95, 20);

	}

}
