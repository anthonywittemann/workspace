/** 
 * @author anthonywittemann
 * Chapter 10 Pr 5
 * In class 4/24/14
 */
public class AWEmptyStringException extends Exception{
	
	public AWEmptyStringException(){
		super("Error: Empty String");
	}
	
}
