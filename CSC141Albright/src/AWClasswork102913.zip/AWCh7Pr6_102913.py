# Anthony Wittemann
# 10/29/13
# Chapter 7 Program 1 - 8
# Program 6 - Average of Numbers

def main():
    nums = open('numbers.txt', 'r')
    line = nums.readline()
    the_sum = 0
    count = 0
    while line != '':
        the_sum += int(line)
        line = nums.readline()
        count += 1
    nums.close()
    avg = the_sum / count * 1.0
    print('There average is: ', avg)   
    
main()
