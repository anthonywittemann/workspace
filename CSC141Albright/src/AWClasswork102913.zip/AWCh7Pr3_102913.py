# Anthony Wittemann
# 10/29/13
# Chapter 7 Program 1 - 8
# Program 3 - Line Numbers

def main():
    file_name = input('Enter the file name ')
    the_file = open(file_name, 'r')
    line = the_file.readline()
    line_num = 1
    while line != '':
        line = line.rstrip('\n')
        print(line_num, ': ', line)
        line_num += 1
        line = the_file.readline()
    the_file.close()
        
    
main()
