print("Kate Austen")
print("123 Dharma Lane")
print("Asheville, NC 28899")
