print('Your assignment is to read "Hamlet" by tomorrow.')
